require('./select.min.css');

const $ = require('jquery');
const select2 = require('./select2.min');
console.log($);
select2();
console.log(select2);
module.exports = {
    select2: select2(),
    render(data, cfg) {
        this.data = data;
        this.cfg = cfg;
        var selID = 'select#' + this.id;
        $(selID).select2({
                placeholder: '请选择区域',
                allowClear: true,
                data: data
            })
            //    select2($(selID), this);
            // select2($(selID), {
            //     placeholder: '请选择区域',
            //     allowClear: true,
            //     data: cfg.source
            // })
    },
    renderContainer() {
        this.id = Math.floor(Math.random() * 1000000000000);
        return `<select name="mySelect" style="width:150px;" id="${this.id}"></select>`
    }
}