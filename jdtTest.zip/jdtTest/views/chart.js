const echarts = require('./echarts.min');
module.exports = {
    render(data, cfg) {
        let result = [];
        //颜色处理
        if (cfg.colorArr && cfg.colorArr.length > 0) {
            var colorArr = []
            for (var i = 0; i < cfg.colorArr.length; i++) {
                var col = cfg.colorArr[i]['color'];
                colorArr.push(col);
            }
            cfg.color = colorArr;
        } else {
            if ('color' in cfg) {
                delete cfg.color
            }
        }
        var legendData = [];
        for (var i = 0; i < data.length; i++) {
            legendData.push(data[i]['name']);
        }
        //  delete cfg.colorArr
        // for (var i = 0; i < data.length; i++) {
        //     if (typeof cfg.colorArr[i] == 'object') {
        //         var color1 = cfg.colorArr[i]['frome'];
        //         var color2 = cfg.colorArr[i]['to'];
        //     } else {
        //         var color1 = cfg.colorArr[i]['color'];
        //         var color2 = cfg.colorArr[i]['color'];
        //     }
        //     var colorValue = new echarts.graphic.LinearGradient(0, 0, 1, 0, [
        //         { 'offset': 0, 'color': color1 },
        //         { 'offset': 1, 'color': color2 }
        //     ])
        //     data[i].itemStyle = {
        //         'normal': {
        //             'color': colorValue
        //         }
        //     }
        // }
        var option = {
            tooltip: {

            },
            legend: {
                data: legendData,
                orient: 'horizontal',
                x: 'center',
                y: 'bottom',
                itemGap: 10,
                itemWidth: 10,
                itemHeight: 8,
                textStyle: {
                    color: '#17D1E3'
                }
            },
            grid: {

            },
            xAxis: {
                show: false
            },
            yAxis: {
                show: false,
                type: 'category',
                data: []
            }
        };
        option.color = cfg.color ? cfg.color : {};
        option.series = data;
        var myChart = echarts.init(document.getElementById(this.id));
        myChart.setOption(option);
    },
    renderContainer() {
        this.id = Math.floor(Math.random() * 10000000000);
        return `<div id="${this.id}" style="width: 100%;height: 100%"></div>`;
    }
}