const echarts = require('./echarts.min');
module.exports = {
    render(data, cfg) {
        let result = [];
        //颜色处理
        if (cfg.colorArr && cfg.colorArr.length > 0) {
            var colorArr = []
            for (var i = 0; i < cfg.colorArr.length; i++) {
                var col = cfg.colorArr[i]['color'];
                colorArr.push(col);
            }
            cfg.color = colorArr;
        } else {
            if ('color' in cfg) {
                delete cfg.color
            }
        }
        var tooltipPositionArr = [];
        tooltipPositionArr.push(cfg.tooltipPosition.x);
        tooltipPositionArr.push(cfg.tooltipPosition.y);
        //   delete cfg.colorArr
        var option = {
            title: {},
            tooltip: {
                trigger: 'item',
                formatter: "{b} : {c} ({d}%)",
                position: tooltipPositionArr,
                textStyle: {
                    color: 'lightblue'
                }
            },
            legend: { show: false },
            toolbox: {},
            calculable: false,
            series: [{
                name: false,
                type: 'pie',
                center: ['50%', '50%'],
                roseType: 'radius',
                label: {
                    normal: {
                        show: false
                    },
                    emphasis: {
                        show: false
                    }
                },
                lableLine: {
                    normal: {
                        show: false
                    },
                    emphasis: {
                        show: false
                    }
                }
            }]
        };

        option.series[0].data = data;
        option.color = cfg.color ? cfg.color : {};
        var myChart = echarts.init(document.getElementById(this.id));
        myChart.setOption(option);
    },
    renderContainer() {
        this.id = Math.floor(Math.random() * 10000000000);
        return `<div id="${this.id}" style="width: 100%;height: 100%"></div>`;
    }
}