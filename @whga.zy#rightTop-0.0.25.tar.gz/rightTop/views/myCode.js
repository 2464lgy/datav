require('./style.css');
const $ = require('jquery');
module.exports = {
    render(data, cfg) {

        this.data = data;
        this.cfg = cfg;
        let ID = this.id
        let CFGMY = cfg;
        // 放置背景图片
        $('#' + ID + ' .menuOpen').css('backgroundImage', 'url("' + this.cfg['toggleBG']['close'] + '")');
        $('#' + ID + ' .menuButton button').each(function(i, el) {
            console.log(i);
            $(el).css('backgroundImage', 'url("' + CFGMY["buttonBG"][i]["value1"] + '")');
            console.log(el);
        })
        $('#' + ID + ' .menuFirst ul').empty();
        $('#' + ID + ' .menuSecond ul').empty();
        $('#' + ID + ' .menuThree ul').empty();


        for (var i = 0; i < data.length; i++) {
            $('#' + ID + ' .menuFirst ul').append('<li>' + data[i]["name"] + '</li>');
            if (data[i]["children"]) {
                for (var j = 0; j < data[i]['children'].length; j++) {
                    $('#' + ID + ' .menuSecond ul').append('<li class="' + data[i]['name'] + '">' + data[i]['children'][j]["name"] + '</li>');
                    if (data[i]['children'][j]['children']) {
                        for (var k = 0; k < data[i]['children'][j]['children'].length; k++) {
                            $('#' + ID + ' .menuThree ul').append('<li' +
                                ' class="' + data[i]['children'][j]['name'] + ' ' + data[i]['name'] +
                                '" id="' + data[i]["children"][j]["children"][k]["id"] + '">' +
                                data[i]['children'][j]['children'][k]['name'] +
                                '</li>');
                        }
                    }
                }
            }
        }
        $('#' + ID + ' .menuOpen').on('click', function() {
            $(this).toggleClass('active');

            if ($(this).hasClass('active')) {
                $(this).css('backgroundImage', 'url("' + CFGMY['toggleBG']['open'] + '")');
            } else {
                $(this).css('backgroundImage', 'url("' + CFGMY['toggleBG']['close'] + '")');
            }
            $('#' + ID + ' .menuButton').toggleClass('active');
            $('#' + ID + ' .menuCon').hide();
        });
        $('#' + ID + ' .menuButton button').on('click', function() {
            $(this).toggleClass('active');
            if ($(this).hasClass('active')) {
                $(this).css('backgroundImage', 'url("' + CFGMY['buttonBG'][$(this).index()]['value2'] + '")');
            } else {
                $(this).css('backgroundImage', 'url("' + CFGMY['buttonBG'][$(this).index()]['value1'] + '")');
            }
            $('#' + ID + ' .menuFirst').show().scrollTop(0);
            $('#' + ID + ' .menuSecond,.menuThree').hide();
        });
        $('#' + ID + ' .menuFirst ul li').on('click', function() {
            $('#' + ID + ' .menuFirst ul li').removeClass('active');
            $(this).addClass('active');

            $('#' + ID + ' .menuSecond ul li').hide();
            $('#' + ID + ' .menuSecond ul li.' + $(this).text()).show();
            $('#' + ID + ' .menuSecond').show().scrollTop(0);
            $('#' + ID + ' .menuThree').hide();
        });
        $('#' + ID + ' .menuSecond ul li').on('click', function() {
            $('#' + ID + ' .menuSecond ul li').removeClass('active');

            $('#' + ID + ' .menuThree ul li').hide();
            $('#' + ID + ' .menuThree ul li.' + $(this).text() + '.' + $(this).attr('class')).show();
            $('#' + ID + ' .menuThree').show().scrollTop(0);
            $(this).addClass('active');

        })


    },
    renderContainer() {
        this.id = Math.floor(Math.random() * 100000000000000000);
        return `
        <div id="${this.id}"  class="main" style="width: 920px;height: auto;margin: auto;">
        <div class="menuOpen"></div>
        <div class="menuButton" style="">
                              <button class="btn1"></button>
                              <button class="btn2"></button>
                              <button class="btn3"></button>
                              <button class="btn4"></button>
                              <button class="btn5"></button>
                              <button class="btn6"></button>
        </div>
        <div class="menuCon menuFirst">
            <ul>
            </ul>
        </div>
        <div class="menuCon menuSecond">
            <ul>
            </ul>
        </div>
        <div class="menuCon menuThree">
            <ul>
            </ul>
        </div>

        <div style="clear: both;"></div>
    </div>
        `
    }
}